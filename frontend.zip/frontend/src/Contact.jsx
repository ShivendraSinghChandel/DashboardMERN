const Contact=()=>{
    return(
        <>
           <hr size="4" color="red"/>
           <h1>This is contact page</h1>
           <hr size="4" color="red"/>
        </>
    )
}


export default Contact;