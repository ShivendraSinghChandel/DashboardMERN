const StuDesign=(props)=>{
      return(
        <>
          <tr>
            <td>{props.rno}</td>
            <td>{props.nm}</td>
            <td>{props.ct}</td>
            <td>{props.fs}</td>
          </tr>
        </>
      )
}

export default StuDesign;