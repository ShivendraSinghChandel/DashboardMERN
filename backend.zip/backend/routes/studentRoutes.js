const express=require("express");

const route=express.Router();

const stuControllers=require("../controller/studentControllers");

route.post("/stusave",stuControllers.stuDataSave);

route.get("/studisplay",stuControllers.stuDisplay);

route.post("/stusearch",stuControllers.stuSearch)

route.get("/updatedisplay",stuControllers.updateDisplay)

route.post("/updatedatadelete",stuControllers.updateDataDelete);

module.exports=route;