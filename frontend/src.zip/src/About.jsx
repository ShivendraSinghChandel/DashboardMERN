const About=()=>{
    return(
        <>
           <hr size="4" color="red"/>
           <h1>This is About page</h1>
           <hr size="4" color="red"/>
        </>
    )
}


export default About;