const Home=()=>{
    return(
        <>
           <hr size="4" color="red"/>
           <h1>This is home page</h1>
           <hr size="4" color="red"/>
        </>
    )
}


export default Home;